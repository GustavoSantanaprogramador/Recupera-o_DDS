/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.prova_gustavo_q3;

import javax.swing.JOptionPane;

/**
 *
 * @author gsantana
 */
public class Prova_Gustavo_Q3 {

    public static void main(String[] args) {
        System.out.println("Digite um número");
        
      int valor = Integer.parseInt(JOptionPane.showInputDialog(null,"Digite um número"));
       
       JOptionPane.showMessageDialog(null,"O seu antecessor é: " +(valor-1));
               
       JOptionPane.showMessageDialog(null,"O seu sucessor é: " +(valor+1));
      
       
    }
}
