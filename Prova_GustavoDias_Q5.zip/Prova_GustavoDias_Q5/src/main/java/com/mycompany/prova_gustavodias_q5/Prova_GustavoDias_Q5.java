/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.prova_gustavodias_q5;

import javax.swing.JOptionPane;

/**
 *
 * @author gsantana
 */
public class Prova_GustavoDias_Q5 {

    public static void main(String[] args) {
       
        
        int[] vetor = new int[1];
        int numAux = 0;
        int media = 0;
        
        
        
        
        JOptionPane.showMessageDialog(null,"Olá PROF :)");
        int quant = Integer.parseInt(JOptionPane.showInputDialog(null,"Digite a quantidade de valores para a operação:"));
         numAux = quant;
         
        for(int i=0; i <= numAux ; i++ ){   
          int num = Integer.parseInt(JOptionPane.showInputDialog(null,"Digite um número"));
           vetor[i] = num; 
             
    }
        
       
        
        
         
         
    }
}
