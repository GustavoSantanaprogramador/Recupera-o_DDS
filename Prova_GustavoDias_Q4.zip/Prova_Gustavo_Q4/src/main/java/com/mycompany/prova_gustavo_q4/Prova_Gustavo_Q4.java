/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.prova_gustavo_q4;

import java.util.Scanner;
import javax.swing.JOptionPane;

/**
 *
 * @author gsantana
 */
public class Prova_Gustavo_Q4 {

    public static void main(String[] args) {
        System.out.println("Digite o seu código:");
        
       // Scanner ler = new Scanner(System.in);
       
       int cod = Integer.parseInt(JOptionPane.showInputDialog(null,"Digite o código: "));
       
       if(cod == 1234){
           int senha = Integer.parseInt(JOptionPane.showInputDialog(null,"Digite a sua senha: "));
           
            if(senha == 9999){
                JOptionPane.showMessageDialog(null,"Acesso permitido"); 
               
               
            }
             JOptionPane.showMessageDialog(null,"Senha incorreta");
             
           
       }
        JOptionPane.showMessageDialog(null,"Usuário Inválido"); 
    
        
    
       
        
       
            
        
    }
}
